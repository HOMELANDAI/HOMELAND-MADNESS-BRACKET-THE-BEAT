# Admin Checklist - Beat Upload Patch

## Before upload

- [ ] Tournament slug exists.
- [ ] Regions are defined.
- [ ] Committee deadline is set.
- [ ] Beat upload template is current.
- [ ] Rights/compliance status is understood for proof-of-concept vs public launch.

## During upload

- [ ] CSV/JSON file uploaded.
- [ ] Required headers confirmed.
- [ ] Producer names present.
- [ ] Attached song titles present.
- [ ] Release years present.
- [ ] Source links included where possible.
- [ ] Preview durations set between 10 and 30 seconds.
- [ ] Duplicate seeds checked.
- [ ] Duplicate songs checked.

## Verification

- [ ] All official bracket beats marked verified or needs_research.
- [ ] Disputed producer credits flagged.
- [ ] Release-year disputes flagged.
- [ ] Remix/original version issues resolved.
- [ ] Blind Mode eligibility checked.
- [ ] Mini-player preview fields checked.

## Single beat changes

- [ ] Modification request submitted.
- [ ] Old values and new values compared.
- [ ] Reason included.
- [ ] Admin reviewed.
- [ ] Verification log updated.
- [ ] Tournament bracket regenerated if seed changed.
