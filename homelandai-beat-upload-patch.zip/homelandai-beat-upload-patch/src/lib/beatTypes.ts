export type VerificationStatus =
  | 'unverified'
  | 'needs_research'
  | 'verified'
  | 'disputed'
  | 'rejected'
  | 'archived';

export type RightsStatus =
  | 'unknown'
  | 'internal_demo_only'
  | 'platform_embed'
  | 'cleared'
  | 'rejected';

export type BeatUploadRow = {
  tournament_slug: string;
  region?: string;
  seed?: number;
  beat_title: string;
  song_title: string;
  artist_name: string;
  producer_name: string;
  release_year: number;
  release_date?: string;
  source_platform?: string;
  source_url?: string;
  preview_url?: string;
  preview_start_seconds?: number;
  preview_duration_seconds?: number;
  is_blind_mode_eligible?: boolean;
  committee_notes?: string;
  verification_status?: VerificationStatus;
  verification_notes?: string;
  rights_status?: RightsStatus;
};

export type BeatValidationResult = {
  valid: boolean;
  errors: string[];
  warnings: string[];
};

export type BeatModificationAction =
  | 'add'
  | 'remove'
  | 'replace'
  | 'edit_metadata'
  | 'reverify'
  | 'restore';

export type BeatModificationRequest = {
  tournament_slug: string;
  action_type: BeatModificationAction;
  old_beat_id?: string;
  reason: string;
  requested_by?: string;
  new_beat_payload?: Partial<BeatUploadRow>;
};
