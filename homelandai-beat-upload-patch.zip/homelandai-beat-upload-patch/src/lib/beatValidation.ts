import type { BeatUploadRow, BeatValidationResult } from './beatTypes';

const YEAR_MIN = 1900;
const YEAR_MAX = 2100;

function isProbablyUrl(value?: string): boolean {
  if (!value) return false;
  try {
    const url = new URL(value);
    return url.protocol === 'http:' || url.protocol === 'https:';
  } catch {
    return false;
  }
}

export function validateBeatRow(row: Partial<BeatUploadRow>): BeatValidationResult {
  const errors: string[] = [];
  const warnings: string[] = [];

  if (!row.tournament_slug) errors.push('Missing tournament_slug.');
  if (!row.beat_title) errors.push('Missing beat_title.');
  if (!row.song_title) errors.push('Missing song_title attached to the beat.');
  if (!row.artist_name) errors.push('Missing artist_name.');
  if (!row.producer_name) errors.push('Missing producer_name.');

  if (row.release_year === undefined || row.release_year === null) {
    errors.push('Missing release_year.');
  } else if (!Number.isInteger(Number(row.release_year))) {
    errors.push('release_year must be a four-digit number.');
  } else if (Number(row.release_year) < YEAR_MIN || Number(row.release_year) > YEAR_MAX) {
    errors.push(`release_year must be between ${YEAR_MIN} and ${YEAR_MAX}.`);
  }

  if (row.seed !== undefined && row.seed !== null && Number(row.seed) < 1) {
    errors.push('seed must be greater than zero.');
  }

  if (row.source_url && !isProbablyUrl(row.source_url)) {
    errors.push('source_url must be a valid http(s) URL.');
  }

  if (row.preview_url && !isProbablyUrl(row.preview_url)) {
    errors.push('preview_url must be a valid http(s) URL.');
  }

  const previewDuration = Number(row.preview_duration_seconds ?? 20);
  if (previewDuration < 10 || previewDuration > 30) {
    errors.push('preview_duration_seconds must be between 10 and 30.');
  }

  const previewStart = Number(row.preview_start_seconds ?? 0);
  if (previewStart < 0) {
    errors.push('preview_start_seconds cannot be negative.');
  }

  if (!row.release_date) warnings.push('Missing release_date. Release year is acceptable for MVP, but exact date is preferred.');
  if (!row.source_url) warnings.push('Missing source_url. Verification will remain weak until a source is attached.');
  if (!row.preview_url) warnings.push('Missing preview_url. Mini-player may be disabled until preview is configured.');
  if (!row.committee_notes) warnings.push('Missing committee_notes. Selection Sunday defense will be weaker.');
  if (!row.rights_status || row.rights_status === 'unknown') warnings.push('rights_status is unknown. Use only for internal demo until cleared.');

  return {
    valid: errors.length === 0,
    errors,
    warnings,
  };
}

export function validateBeatBatch(rows: Partial<BeatUploadRow>[]): { validRows: number; invalidRows: number; warnings: number; rowResults: BeatValidationResult[] } {
  const rowResults = rows.map(validateBeatRow);
  return {
    validRows: rowResults.filter((r) => r.valid).length,
    invalidRows: rowResults.filter((r) => !r.valid).length,
    warnings: rowResults.reduce((sum, r) => sum + r.warnings.length, 0),
    rowResults,
  };
}
