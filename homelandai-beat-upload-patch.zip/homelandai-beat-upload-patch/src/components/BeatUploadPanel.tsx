'use client';

import { useState } from 'react';

type UploadSummary = {
  totalRows: number;
  validRows: number;
  invalidRows: number;
  warningRows: number;
};

export function BeatUploadPanel() {
  const [summary, setSummary] = useState<UploadSummary | null>(null);

  async function handleUpload(file: File) {
    // Wire this to Supabase Storage + Edge Function verify-beat-batch.
    setSummary({ totalRows: 0, validRows: 0, invalidRows: 0, warningRows: 0 });
    console.log('Upload selected:', file.name);
  }

  return (
    <section className="rounded-2xl border border-cyan-400/40 bg-black/80 p-6 text-white shadow-lg shadow-cyan-500/10">
      <div className="mb-4">
        <p className="text-xs uppercase tracking-[0.3em] text-cyan-300">HomelandAI Admin</p>
        <h2 className="text-2xl font-black uppercase">Beat Set Upload</h2>
        <p className="mt-2 text-sm text-slate-300">
          Upload a tournament beat set, validate metadata, and prepare entries for committee seeding.
        </p>
      </div>

      <label className="block rounded-xl border border-dashed border-red-500/60 p-6 text-center hover:bg-red-500/10">
        <input
          type="file"
          accept=".csv,.json"
          className="hidden"
          onChange={(event) => {
            const file = event.target.files?.[0];
            if (file) handleUpload(file);
          }}
        />
        <span className="font-bold uppercase text-red-300">Upload CSV or JSON Beat Set</span>
        <span className="mt-2 block text-xs text-slate-400">Required: producer, song title, artist, release year, source notes.</span>
      </label>

      {summary && (
        <div className="mt-4 grid grid-cols-4 gap-3 text-center text-sm">
          <div className="rounded-lg bg-slate-900 p-3">Rows: {summary.totalRows}</div>
          <div className="rounded-lg bg-slate-900 p-3">Valid: {summary.validRows}</div>
          <div className="rounded-lg bg-slate-900 p-3">Invalid: {summary.invalidRows}</div>
          <div className="rounded-lg bg-slate-900 p-3">Warnings: {summary.warningRows}</div>
        </div>
      )}
    </section>
  );
}
