'use client';

import { useState } from 'react';

const actions = ['add', 'remove', 'replace', 'edit_metadata', 'reverify', 'restore'] as const;

export function BeatModificationPanel() {
  const [action, setAction] = useState<(typeof actions)[number]>('edit_metadata');

  return (
    <section className="rounded-2xl border border-red-500/40 bg-zinc-950 p-6 text-white">
      <p className="text-xs uppercase tracking-[0.3em] text-red-300">Single Beat Control</p>
      <h2 className="text-2xl font-black uppercase">Beat Modification Request</h2>
      <p className="mt-2 text-sm text-zinc-300">
        Add, remove, replace, edit, reverify, or restore one beat without re-uploading the full tournament pool.
      </p>

      <div className="mt-5 grid gap-4 md:grid-cols-2">
        <label className="text-sm">
          Action Type
          <select className="mt-1 w-full rounded-lg bg-black p-3" value={action} onChange={(e) => setAction(e.target.value as typeof action)}>
            {actions.map((item) => (
              <option key={item} value={item}>{item}</option>
            ))}
          </select>
        </label>
        <label className="text-sm">
          Old Beat ID
          <input className="mt-1 w-full rounded-lg bg-black p-3" placeholder="Required for remove, replace, edit, reverify" />
        </label>
        <label className="text-sm md:col-span-2">
          Reason
          <textarea className="mt-1 min-h-28 w-full rounded-lg bg-black p-3" placeholder="Explain why this beat needs to be changed." />
        </label>
      </div>

      <button className="mt-5 rounded-xl bg-red-600 px-5 py-3 font-black uppercase hover:bg-red-500">
        Submit Modification Request
      </button>
    </section>
  );
}
