type Props = {
  status: 'unverified' | 'needs_research' | 'verified' | 'disputed' | 'rejected' | 'archived';
  score?: number;
};

const labelMap = {
  unverified: 'Unverified',
  needs_research: 'Needs Research',
  verified: 'Verified',
  disputed: 'Disputed',
  rejected: 'Rejected',
  archived: 'Archived',
};

export function BeatVerificationStatus({ status, score = 0 }: Props) {
  return (
    <div className="inline-flex items-center gap-2 rounded-full border border-cyan-400/30 bg-black px-3 py-1 text-xs uppercase tracking-wide text-cyan-100">
      <span className="h-2 w-2 rounded-full bg-cyan-300" />
      <span>{labelMap[status]}</span>
      <span className="text-zinc-400">Score {score}/100</span>
    </div>
  );
}
