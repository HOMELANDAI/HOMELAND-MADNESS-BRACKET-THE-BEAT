#!/usr/bin/env node
/*
  Basic local CSV validator for HomelandAI Madness beat uploads.
  Usage: node scripts/validate-beat-upload.js templates/beat-upload-template.csv
*/

const fs = require('fs');
const path = process.argv[2];

if (!path) {
  console.error('Usage: node scripts/validate-beat-upload.js <file.csv>');
  process.exit(1);
}

const text = fs.readFileSync(path, 'utf8').trim();
const [headerLine, ...lines] = text.split(/\r?\n/);
const headers = headerLine.split(',');

const required = ['tournament_slug', 'beat_title', 'song_title', 'artist_name', 'producer_name', 'release_year'];
const missingHeaders = required.filter((field) => !headers.includes(field));
if (missingHeaders.length) {
  console.error('Missing required headers:', missingHeaders.join(', '));
  process.exit(1);
}

let invalidRows = 0;

lines.forEach((line, idx) => {
  const values = line.split(',');
  const row = Object.fromEntries(headers.map((h, i) => [h, values[i] ?? '']));
  const errors = [];

  for (const field of required) {
    if (!row[field]) errors.push(`Missing ${field}`);
  }

  const year = Number(row.release_year);
  if (!Number.isInteger(year) || year < 1900 || year > 2100) {
    errors.push('Invalid release_year');
  }

  const duration = Number(row.preview_duration_seconds || 20);
  if (duration < 10 || duration > 30) errors.push('Invalid preview_duration_seconds');

  if (errors.length) {
    invalidRows += 1;
    console.error(`Row ${idx + 2}: ${errors.join('; ')}`);
  }
});

console.log(`Validated ${lines.length} rows. Invalid rows: ${invalidRows}.`);
process.exit(invalidRows ? 1 : 0);
