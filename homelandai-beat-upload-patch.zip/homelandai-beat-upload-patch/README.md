# HomelandAI Madness - Beat Upload Patch

Patch name: **Beat Upload + Single Beat Modification System**  
Project: **HomelandAI Madness: Bracket the Beat by HAI**  
Backend: **Supabase**

This patch adds a clear tournament beat upload workflow for HomelandAI Madness. It supports full tournament beat set uploads, single beat addition, removal, replacement, modification, verification status, and metadata validation for producer, attached song titles, release year, source links, preview configuration, and bracket readiness.

## What this patch adds

- Bulk tournament beat upload template using CSV and JSON.
- Supabase schema for beat catalog records, tournament beat sets, upload batches, verification logs, and modification history.
- Single beat modification workflow:
  - Add beat
  - Remove beat
  - Replace beat
  - Edit metadata
  - Re-verify metadata
  - Restore archived beat
- Verification fields for:
  - Producer
  - Song title attached to beat
  - Artist
  - Year of release
  - Source/platform links
  - Preview source and preview duration
  - Licensing/review status placeholder
- Admin-facing notes and UI component scaffold.
- Edge function scaffold for validating beat upload batches.
- Sample data templates.

## Repository structure

```text
homelandai-beat-upload-patch/
  README.md
  PATCH_NOTES.md
  docs/
    beat-upload-workflow.md
    single-beat-modification.md
    verification-rules.md
    admin-ux-spec.md
  templates/
    beat-upload-template.csv
    beat-upload-template.json
    beat-modification-request.json
  supabase/
    migrations/
      001_beat_upload_patch.sql
    functions/
      verify-beat-batch/
        index.ts
  src/
    lib/
      beatValidation.ts
      beatTypes.ts
    components/
      BeatUploadPanel.tsx
      BeatModificationPanel.tsx
      BeatVerificationStatus.tsx
  admin/
    admin-checklist.md
  scripts/
    validate-beat-upload.js
  tests/
    beat-upload-sample.invalid.csv
    beat-upload-sample.valid.csv
```

## Integration instructions

1. Copy this patch into the main `homelandai-madness-bracket-the-beat` repository.
2. Apply the Supabase migration in `supabase/migrations/001_beat_upload_patch.sql`.
3. Add the validation helpers from `src/lib` into the app backend or admin dashboard.
4. Add the admin components into the tournament admin dashboard.
5. Use `templates/beat-upload-template.csv` for every tournament beat upload.
6. Run the local validation script before importing bulk data.

## Core admin workflow

1. Create tournament.
2. Upload beat set CSV/JSON.
3. Validate required fields.
4. Flag missing producer/title/year/source data.
5. Verify entries manually or through research workflow.
6. Lock verified beat pool.
7. Assign committee seedings.
8. Allow single beat changes only through controlled modification requests.
9. Preserve modification history for auditability.

## Important compliance note

This patch tracks metadata and preview references. It does not grant music rights. Public use of previews, hosted audio, or platform playback should be reviewed for licensing, platform API compliance, and contest/prize regulations before launch.
