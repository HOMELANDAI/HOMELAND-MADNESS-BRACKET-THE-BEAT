// Supabase Edge Function scaffold
// Purpose: validate a CSV/JSON beat upload batch before publishing.

import { serve } from 'https://deno.land/std@0.224.0/http/server.ts';

type BeatRow = {
  tournament_slug?: string;
  beat_title?: string;
  song_title?: string;
  artist_name?: string;
  producer_name?: string;
  release_year?: number;
  source_url?: string;
  preview_url?: string;
  preview_duration_seconds?: number;
};

function validate(row: BeatRow) {
  const errors: string[] = [];
  const warnings: string[] = [];

  if (!row.tournament_slug) errors.push('Missing tournament_slug.');
  if (!row.beat_title) errors.push('Missing beat_title.');
  if (!row.song_title) errors.push('Missing song_title.');
  if (!row.artist_name) errors.push('Missing artist_name.');
  if (!row.producer_name) errors.push('Missing producer_name.');
  if (!row.release_year) errors.push('Missing release_year.');
  if (row.release_year && (row.release_year < 1900 || row.release_year > 2100)) errors.push('Invalid release_year.');
  if (!row.source_url) warnings.push('Missing source_url.');
  if (!row.preview_url) warnings.push('Missing preview_url.');
  if (row.preview_duration_seconds && (row.preview_duration_seconds < 10 || row.preview_duration_seconds > 30)) {
    errors.push('preview_duration_seconds must be between 10 and 30.');
  }

  return { valid: errors.length === 0, errors, warnings };
}

serve(async (req) => {
  if (req.method !== 'POST') {
    return new Response(JSON.stringify({ error: 'Method not allowed' }), { status: 405 });
  }

  const body = await req.json().catch(() => null);
  const rows: BeatRow[] = Array.isArray(body?.beats) ? body.beats : [];

  const rowResults = rows.map(validate);

  return new Response(
    JSON.stringify({
      totalRows: rows.length,
      validRows: rowResults.filter((r) => r.valid).length,
      invalidRows: rowResults.filter((r) => !r.valid).length,
      warnings: rowResults.reduce((sum, r) => sum + r.warnings.length, 0),
      rowResults,
    }),
    { headers: { 'content-type': 'application/json' } },
  );
});
