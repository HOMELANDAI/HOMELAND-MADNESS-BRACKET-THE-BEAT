-- HomelandAI Madness: Bracket the Beat
-- Patch: Beat Upload + Single Beat Modification System

create extension if not exists "pgcrypto";

-- Upload batches track every bulk upload event.
create table if not exists public.beat_upload_batches (
  id uuid primary key default gen_random_uuid(),
  tournament_slug text not null,
  upload_mode text not null default 'draft' check (upload_mode in ('draft', 'verification', 'locked_pool')),
  file_name text,
  uploaded_by uuid,
  status text not null default 'pending' check (status in ('pending', 'validated', 'failed', 'published', 'archived')),
  total_rows integer default 0,
  valid_rows integer default 0,
  invalid_rows integer default 0,
  warning_rows integer default 0,
  error_summary jsonb default '[]'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- Master beat records for tournament use.
create table if not exists public.tournament_beats (
  id uuid primary key default gen_random_uuid(),
  tournament_slug text not null,
  upload_batch_id uuid references public.beat_upload_batches(id) on delete set null,
  region text,
  seed integer,
  beat_title text not null,
  song_title text not null,
  artist_name text not null,
  producer_name text not null,
  release_year integer not null check (release_year between 1900 and 2100),
  release_date date,
  source_platform text,
  source_url text,
  preview_url text,
  preview_start_seconds integer default 0 check (preview_start_seconds >= 0),
  preview_duration_seconds integer default 20 check (preview_duration_seconds between 10 and 30),
  is_blind_mode_eligible boolean default true,
  committee_notes text,
  verification_status text not null default 'unverified' check (verification_status in ('unverified', 'needs_research', 'verified', 'disputed', 'rejected', 'archived')),
  verification_score integer default 0 check (verification_score between 0 and 100),
  verification_notes text,
  verified_by uuid,
  verified_at timestamptz,
  rights_status text not null default 'unknown' check (rights_status in ('unknown', 'internal_demo_only', 'platform_embed', 'cleared', 'rejected')),
  status text not null default 'active' check (status in ('draft', 'active', 'locked', 'archived', 'replaced')),
  replaced_by uuid references public.tournament_beats(id) on delete set null,
  metadata jsonb default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- Prevent duplicate seeds in a region for active/locked records.
create unique index if not exists uniq_tournament_region_seed_active
on public.tournament_beats(tournament_slug, region, seed)
where status in ('active', 'locked') and seed is not null and region is not null;

-- Prevent duplicate exact active beat entries in a tournament.
create unique index if not exists uniq_tournament_song_artist_active
on public.tournament_beats(tournament_slug, lower(song_title), lower(artist_name))
where status in ('active', 'locked');

-- Single beat modification requests and audit log.
create table if not exists public.beat_modification_requests (
  id uuid primary key default gen_random_uuid(),
  tournament_slug text not null,
  action_type text not null check (action_type in ('add', 'remove', 'replace', 'edit_metadata', 'reverify', 'restore')),
  old_beat_id uuid references public.tournament_beats(id) on delete set null,
  new_beat_id uuid references public.tournament_beats(id) on delete set null,
  old_snapshot jsonb,
  new_payload jsonb,
  reason text not null,
  requested_by uuid,
  reviewed_by uuid,
  review_status text not null default 'requested' check (review_status in ('requested', 'under_review', 'approved', 'rejected', 'applied')),
  verification_notes text,
  created_at timestamptz not null default now(),
  reviewed_at timestamptz,
  applied_at timestamptz
);

-- Verification events preserve who checked what.
create table if not exists public.beat_verification_logs (
  id uuid primary key default gen_random_uuid(),
  beat_id uuid not null references public.tournament_beats(id) on delete cascade,
  previous_status text,
  new_status text not null,
  verification_score integer check (verification_score between 0 and 100),
  source_checked text,
  notes text,
  verified_by uuid,
  created_at timestamptz not null default now()
);

-- Update timestamp helper.
create or replace function public.set_updated_at()
returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

drop trigger if exists set_beat_upload_batches_updated_at on public.beat_upload_batches;
create trigger set_beat_upload_batches_updated_at
before update on public.beat_upload_batches
for each row execute function public.set_updated_at();

drop trigger if exists set_tournament_beats_updated_at on public.tournament_beats;
create trigger set_tournament_beats_updated_at
before update on public.tournament_beats
for each row execute function public.set_updated_at();

-- Helper: mark beat verified.
create or replace function public.verify_tournament_beat(
  p_beat_id uuid,
  p_status text,
  p_score integer,
  p_notes text,
  p_verified_by uuid default null
)
returns public.tournament_beats as $$
declare
  v_old_status text;
  v_row public.tournament_beats;
begin
  select verification_status into v_old_status from public.tournament_beats where id = p_beat_id;

  update public.tournament_beats
  set verification_status = p_status,
      verification_score = p_score,
      verification_notes = p_notes,
      verified_by = p_verified_by,
      verified_at = case when p_status = 'verified' then now() else verified_at end
  where id = p_beat_id
  returning * into v_row;

  insert into public.beat_verification_logs(
    beat_id, previous_status, new_status, verification_score, notes, verified_by
  ) values (
    p_beat_id, v_old_status, p_status, p_score, p_notes, p_verified_by
  );

  return v_row;
end;
$$ language plpgsql security definer;

-- Helper: archive/remove beat.
create or replace function public.archive_tournament_beat(
  p_beat_id uuid,
  p_reason text,
  p_requested_by uuid default null
)
returns public.tournament_beats as $$
declare
  v_snapshot jsonb;
  v_row public.tournament_beats;
begin
  select to_jsonb(t) into v_snapshot from public.tournament_beats t where id = p_beat_id;

  update public.tournament_beats
  set status = 'archived', verification_status = 'archived'
  where id = p_beat_id
  returning * into v_row;

  insert into public.beat_modification_requests(
    tournament_slug, action_type, old_beat_id, old_snapshot, reason, requested_by, review_status, applied_at
  ) values (
    v_row.tournament_slug, 'remove', p_beat_id, v_snapshot, p_reason, p_requested_by, 'applied', now()
  );

  return v_row;
end;
$$ language plpgsql security definer;
