# Single Beat Modification Workflow

## Purpose

Tournament operators need the ability to modify one beat without re-uploading the entire tournament set. This is critical when a title is wrong, producer credit needs correction, a beat is removed, or a new replacement is approved.

## Supported actions

### Add

Adds a new beat to the tournament pool.

Use cases:
- Committee adds a late sleeper pick.
- Admin adds replacement after eligibility issue.
- Missing classic is discovered before lock.

### Remove

Archives a beat from the tournament pool without deleting historical records.

Use cases:
- Metadata cannot be verified.
- Rights concern.
- Duplicate entry.
- Committee withdraws selection.

### Replace

Swaps one beat for another while preserving the original modification chain.

Use cases:
- Wrong version was uploaded.
- Better eligible beat replaces disputed entry.
- Regional balance adjustment.

### Edit metadata

Updates details on an existing beat.

Fields commonly edited:
- Producer name
- Attached song title
- Release year
- Artist
- Preview URL
- Committee notes
- Verification status

### Re-verify

Reopens a beat for research review after a dispute.

Use cases:
- Fan challenges producer credit.
- Committee disputes release year.
- Legend guest questions metadata.

## Required modification fields

- `action_type`: add, remove, replace, edit_metadata, reverify, restore
- `reason`
- `requested_by`
- `review_status`
- `old_beat_id` when editing/removing/replacing
- `new_beat_payload` when adding/replacing
- `verification_notes`

## Audit rule

Never hard delete a beat after upload. Use `archived` status and preserve modification history.

## Admin approval states

- `requested`
- `under_review`
- `approved`
- `rejected`
- `applied`

## UX recommendation

Every single beat modification should show:

- Old value
- New value
- Reason for change
- Verification note
- Admin reviewer
- Timestamp
