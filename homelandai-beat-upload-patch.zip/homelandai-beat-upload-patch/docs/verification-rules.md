# Beat Verification Rules

## Verification purpose

HomelandAI Madness depends on credible song metadata. Bad metadata weakens Selection Sunday, committee scoring, Legend Mode, Blind Mode, and The Listen Effect data.

## Verification statuses

- `unverified`: uploaded but not checked
- `needs_research`: missing or disputed metadata
- `verified`: reviewed and approved
- `disputed`: active disagreement or uncertainty
- `rejected`: not eligible for tournament use
- `archived`: removed from active tournament pool

## Required fields for verification

### Song/beat title

Must include the official or commonly accepted title.

### Attached song title

If the beat is known through a song, attach the song title. For instrumentals, include instrumental title or source title.

### Artist name

Primary performing artist or group.

### Producer name

Must identify credited producer(s) where possible. Multiple producers should be comma-separated or stored as array in JSON.

### Release year

Must be a four-digit year. If disputed, use `needs_research` or `disputed`.

### Source link

Preferred sources:
- Official artist/label page
- Licensed music platform page
- Reputable music database
- Publication/interview credit
- Platform metadata page

### Preview configuration

For proof-of-concept mode:
- Preview duration should be 10-30 seconds.
- Store start time and duration.
- Do not assume public rights from metadata.

## Verification scoring

Optional internal score from 0-100:

- 100: official source verified
- 85: multiple reputable sources agree
- 70: credible but not official source
- 50: incomplete but plausible
- 25: disputed or weak source
- 0: rejected/unusable

## Dispute examples

- Producer credit differs across sources.
- Release year differs by single vs album date.
- Remix version accidentally uploaded instead of original.
- Beat attached to wrong song title.
- Duplicate beat entered under alternate title.
