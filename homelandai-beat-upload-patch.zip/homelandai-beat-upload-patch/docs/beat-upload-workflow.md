# Beat Upload Workflow

## Overview

Each tournament needs a verified beat set before committees can create regions and seed matchups. The beat upload process should be treated like roster submission in a sports league.

## Upload modes

### 1. Draft Upload

Early working list. Missing fields are allowed, but records are marked as `draft`.

### 2. Verification Upload

The list is reviewed by admin, committees, or research staff. Missing metadata is flagged.

### 3. Locked Tournament Pool

Only verified beats can move into the official tournament pool. Changes after lock require a modification request.

## Recommended upload fields

- `tournament_slug`
- `region`
- `seed`
- `beat_title`
- `song_title`
- `artist_name`
- `producer_name`
- `release_year`
- `release_date`
- `source_platform`
- `source_url`
- `preview_url`
- `preview_start_seconds`
- `preview_duration_seconds`
- `is_blind_mode_eligible`
- `committee_notes`
- `verification_status`
- `verification_notes`
- `rights_status`

## Upload lifecycle

1. Admin creates tournament shell.
2. Admin uploads CSV or JSON beat file.
3. System creates upload batch.
4. System validates rows.
5. Invalid rows are flagged with specific messages.
6. Admin fixes errors or marks rows for research.
7. Verified rows enter tournament beat pool.
8. Committee can seed verified beats.
9. Tournament lock prevents unapproved edits.

## Validation priorities

High-priority blocking issues:

- Missing song title
- Missing artist name
- Missing producer name
- Missing release year
- Duplicate seed in same region
- Duplicate beat in same tournament
- Invalid preview duration
- Invalid source URL

Non-blocking warnings:

- Missing release date
- Missing committee notes
- Rights status unknown
- Preview URL missing for proof-of-concept mode
- Region not assigned yet
