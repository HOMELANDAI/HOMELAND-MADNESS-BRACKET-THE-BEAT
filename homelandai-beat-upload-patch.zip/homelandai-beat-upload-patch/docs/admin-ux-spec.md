# Admin UX Spec - Beat Upload and Modification

## Admin screens

### Beat Upload Dashboard

Elements:
- Upload CSV/JSON button
- Download template button
- Active tournament selector
- Upload batch history
- Validation status summary
- Error table
- Warning table
- Publish verified beats button

### Beat Pool Table

Columns:
- Status
- Region
- Seed
- Beat title
- Song title
- Artist
- Producer
- Release year
- Verification status
- Preview status
- Rights status
- Actions

Actions:
- View
- Edit
- Replace
- Remove
- Reverify
- Restore

### Single Beat Modification Modal

Fields:
- Action type
- Reason
- Old beat snapshot
- New values
- Source link
- Verification notes
- Submit for review

### Verification Panel

Displays:
- Metadata completeness
- Source links
- Producer credit
- Release year
- Preview duration
- Rights status placeholder
- Admin notes
- Approve/reject buttons

## User-facing protection

If a beat is unverified, it should not appear in:
- Public bracket
- Prediction bracket
- Voting page
- Mini-player preview card
- Legend Mode
- Blind Mode

## Error messages

- Missing producer credit.
- Missing attached song title.
- Release year must be a four-digit year.
- Duplicate seed in this region.
- Duplicate beat already exists in this tournament.
- Preview duration must be between 10 and 30 seconds.
- This beat is locked. Submit a modification request.
