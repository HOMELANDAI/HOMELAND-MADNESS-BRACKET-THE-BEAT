# HomelandAI Madness: Bracket the Beat

**By HAI / HomelandAI**

HomelandAI Madness: Bracket the Beat is a competitive music-voting tournament platform inspired by March Madness bracket pools, hip-hop debate culture, Selection Sunday reveals, live event voting, prediction contests, committee seeding, Legend Mode, Blind Preview Mode, mini-player previews, NPC commentary, and data-driven aftershows.

The product is designed to work as:

- An in-person event experience with private phone voting
- A remote gameplay platform with 10-30 second preview players
- A Twitch-friendly live show and clipping engine
- A Maestro.tv premium interactive experience
- A Supabase-backed app for voting, scoring, brackets, leaderboards, and data capture
- A recurring HomelandAI franchise built around music, culture, debate, and analytics

## Core Tagline

**Vote. Debate. Crown the Era.**

## Core User Promise

This is not only about choosing your favorite beat. It is about predicting what the culture will choose.

## Main Features

- Tournament brackets: 16, 32, or 64 entries
- Regional committee seeding
- Mandatory committee buy-in model
- Fan prediction brackets
- Private phone voting
- Mini-player preview cards for remote gameplay
- Listen-to-Vote XP bonuses
- Blind Preview Mode / No Names Round
- Legend Mode: producer/artist vote revealed beside fan consensus
- Fan Consensus vs Legend's Vote reveal screens
- Committee accountability scoring
- The Listen Effect analytics
- NPC commentary personalities
- Twitch livestream support
- Maestro.tv premium interactive dashboard support
- NFT collectible concepts
- Data Show / aftershow formats
- Supabase backend schema and seed data

## Repository Structure

```txt
homelandai-madness-bracket-the-beat/
├── README.md
├── package.json
├── .env.example
├── docs/
│   ├── game-design-document.md
│   ├── twitch-maestro-analysis.md
│   ├── data-capture-and-listen-effect.md
│   ├── aftershow-bonus-content.md
│   ├── npc-personalities.md
│   ├── committee-rules-scoring.md
│   ├── prize-structure.md
│   └── roadmap.md
├── prompts/
│   ├── google-studio-gemini-website-prompt.md
│   ├── figma-uiux-prompt.md
│   ├── signage-promo-prompts.md
│   └── nft-prompts.md
├── supabase/
│   ├── migrations/
│   │   └── 001_initial_schema.sql
│   └── seed/
│       └── sample_seed.sql
├── src/
│   ├── components/
│   ├── pages/
│   ├── lib/
│   ├── styles/
│   └── data/
└── public/assets/
```

## Quick Start

```bash
npm install
cp .env.example .env.local
npm run dev
```

## Supabase Setup

1. Create a Supabase project.
2. Copy your project URL and anon key into `.env.local`.
3. Run the SQL in `supabase/migrations/001_initial_schema.sql`.
4. Optionally run `supabase/seed/sample_seed.sql`.
5. Connect the frontend to the Supabase tables using `src/lib/supabaseClient.ts`.

## Required Environment Variables

```bash
NEXT_PUBLIC_SUPABASE_URL=
NEXT_PUBLIC_SUPABASE_ANON_KEY=
SUPABASE_SERVICE_ROLE_KEY=
NEXT_PUBLIC_APP_NAME="HomelandAI Madness"
```

## MVP Build Priorities

1. Tournament and bracket display
2. Matchup voting
3. Prediction bracket submission
4. Leaderboard scoring
5. Mini-player preview tracking
6. Listen-to-Vote XP
7. Committee scoring
8. Legend Mode reveal
9. Data Lab dashboard
10. Maestro/Twitch presentation layers

## Legal / Licensing Note

The mini-player preview system should be treated as a UX proof-of-concept unless audio has been cleared, licensed, or embedded through approved platform APIs. For public commercial launch, use licensed previews, approved embeds, platform APIs, or original/cleared audio.

## Brand Direction

Visual style:

- Black concrete / asphalt backgrounds
- Cracked chrome type
- Neon red and Homeland blue glow
- Cassette tape bracket motifs
- Vinyl and crown iconography
- Fireman badge shield collectible identity
- Graffiti textures and soundwave overlays
- Esports broadcast energy
- Premium NFT gallery presentation

## Suggested Product Positioning

**HomelandAI Madness turns music debate into a competitive cultural sport.**
