# NFT Prompt Collection

## Inaugural Shield NFT
A hyper-detailed commemorative shield NFT for “Homeland Madness: Bracket the Beat – Inaugural Edition.” Shield shaped like a classic fireman’s badge with beveled chrome edges and enamel finish. Centerpiece: glowing Homeland crest with neon red and Homeland blue highlights. The words “INAUGURAL SEASON” etched in bold cracked-chrome lettering across the top, “BRACKET THE BEAT” engraved at the bottom arc. Polished enamel, faint spray paint overlays, subtle graffiti accents, glowing soundwave patterns etched into the metal, cinematic studio lighting.

## Champion's Crown NFT
A digital 3D NFT crown for the Homeland Madness Champion. Built from cassette tapes and chrome microphone grills, fused with glowing neon red and blue energy. Engraved text across the rim: “Homeland Madness – Bracket the Beat Champion.” Crown sits on cracked asphalt with faint graffiti glow, surrounded by sparks of golden confetti.

## Bracket Poster NFT
A glowing neon bracket tree NFT styled like graffiti sprayed on a concrete wall. Each bracket slot framed in chrome with faint soundwave animations rippling across the tree. Center headline: “Homeland Madness: Bracket the Beat.” Smoky arena spotlight with turntable outlines faintly glowing.

## Vinyl Medallion NFT
A commemorative medallion NFT shaped like a vinyl record. Outer grooves shimmer with holographic chrome, glowing Homeland blue rim lighting. Centerpiece: Homeland crest in metallic red, surrounded by graffiti-style text: “Vote. Debate. Crown the Era.”

## Upset Alert NFT
A dynamic NFT celebrating legendary upsets in Homeland Madness. Bold graffiti-style “UPSET!” lettering exploding in neon red across cracked concrete. Cheering silhouettes, confetti blasts, tilted crown falling sideways, glowing Homeland crest beneath.

## Committee Badge NFT
A Homeland Madness Committee badge NFT styled like a glowing digital ID pass. Chrome-edged card with neon red and Homeland blue holographic textures. Front face etched with “Committee Selector” in cracked font, with space for dynamic nameplate engraving.
