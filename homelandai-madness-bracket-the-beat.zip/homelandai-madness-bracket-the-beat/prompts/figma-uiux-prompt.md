# Figma UI/UX Prompt

Design a complete high-fidelity Figma UI/UX system for **HomelandAI Madness: Bracket the Beat by HAI**.

## Figma Pages

1. Brand System
2. Design Tokens
3. Components
4. Desktop Website
5. Mobile Website
6. Interactive Bracket
7. Voting Flow
8. Prediction Bracket Flow
9. Selection Sunday Broadcast
10. Committee Dashboard
11. Fan Leaderboard
12. Legend's Vote Reveal
13. Data Lab Dashboard
14. NFT Gallery
15. Events / In-Person Mode
16. Admin Dashboard
17. Prototype Map
18. Developer Handoff Notes

## Design Direction

Make the design feel like a full entertainment platform, not a basic landing page. Use dark premium backgrounds, chrome text, neon red, Homeland blue, glowing brackets, graffiti textures, esports broadcast overlays, and premium collectible presentation.

## Key Components

- Header and mobile nav
- Matchup card
- Song card with mini-player
- Bracket tree
- Vote modal
- Prediction bracket picker
- Leaderboard row
- Committee card
- NPC card
- Legend vote reveal screen
- Data card
- NFT collectible card
- Event card
- Admin controls

## Prototype Flows

- Fan voting
- Prediction bracket submission
- Selection Sunday controversy vote
- Legend Mode reveal
- NFT unlock
- Committee dashboard
