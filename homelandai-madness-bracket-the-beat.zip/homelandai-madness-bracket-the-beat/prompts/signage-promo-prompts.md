# Signage and Promo Prompts

## Main Stage Banner
A massive digital banner for “HOMELAND MADNESS: BRACKET THE BEAT.” Bold tournament lettering in cracked chrome texture, glowing neon red and Homeland blue outline. A cassette tape split in half forms a bracket tree extending outward with glowing matchup nodes. Tagline below: “Vote. Debate. Crown the Era.” Background: gritty asphalt texture with spray-paint streaks and faint soundwave overlays. Ultra-detailed cinematic sports-arena style.

## Bracket Reveal Screen
A widescreen Selection Sunday style reveal screen for Homeland Madness. Giant bracket tree in glowing chrome neon, matchup slots filling in with animation sparks. Headline: “Homeland Madness: Bracket the Beat – East Coast 90s Edition.” Background: smoky stage lighting with faint turntable and cassette graphics. High-energy esports broadcast vibe.

## Fan Consensus vs Legend's Vote
A dramatic broadcast overlay screen for Homeland Madness: Bracket the Beat showing Fan Consensus vs Legend’s Vote. Split-screen layout with fan percentage bars on the left, Legend’s locked pick on the right, glowing HAI crown in the center, neon red and blue bracket lines, chrome labels, smoky concrete background, esports lower-thirds, and data-panel styling.
