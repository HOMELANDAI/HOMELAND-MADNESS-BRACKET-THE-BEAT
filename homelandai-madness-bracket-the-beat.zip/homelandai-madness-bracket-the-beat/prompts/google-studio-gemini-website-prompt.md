# Google Studio Gemini Website Prompt

Build a complete responsive website/web app for **HomelandAI Madness: Bracket the Beat by HAI**.

The website should feel like ESPN tournament coverage fused with hip-hop debate culture, Twitch overlays, Maestro.tv premium interactivity, and HomelandAI futuristic branding.

## Visual Style

- Black concrete/asphalt backgrounds
- Cracked chrome title typography
- Neon red and Homeland blue glow
- Cassette tape bracket motifs
- Vinyl medallion shapes
- Crown and shield iconography
- Graffiti textures
- Soundwave overlays
- Smoky arena lighting
- Premium NFT gallery styling

## Required Pages

1. Home
2. How It Works
3. Bracket
4. Vote / Matchup Detail
5. Prediction Bracket
6. Leaderboard
7. Selection Sunday
8. Committees
9. Legend's Vote
10. Data Lab
11. NFT Collectibles
12. Events
13. Rules and Prizes
14. Admin Dashboard

## Core Interactivity

- 16/32/64 team brackets
- Private phone voting
- Mini-player previews for each entry
- Listen-to-Vote XP
- Blind Preview Mode
- Legend Compare Mode
- Prediction bracket scoring
- Committee scoring
- Leaderboards
- NFT unlock states
- Social sharing
- Data dashboard

## Supabase Backend

Use Supabase tables for users, tournaments, entries, matchups, votes, predictions, committees, scores, legends, badges, NFTs, and events.

## Troubleshooting

Handle duplicate votes, closed matchups, missing entries, user not logged in, prediction lock errors, leaderboard delays, and missing media previews.
