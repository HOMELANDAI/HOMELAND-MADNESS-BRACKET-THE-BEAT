# Product Roadmap

## Phase 1: MVP

- Supabase schema
- Tournament creation
- Bracket display
- Matchup voting
- Prediction bracket lock
- Basic leaderboard
- Mini-player placeholder
- Listen-to-Vote XP
- Admin controls

## Phase 2: Event Layer

- QR code venue voting
- Selection Sunday page
- NPC commentary cards
- Upset Alert graphics
- Staff aftershow tools
- Twitch stream embeds

## Phase 3: Premium Platform

- Maestro.tv interactive hub
- Legend Mode
- Blind Preview Mode
- Committee dashboard
- Data Lab analytics
- Premium aftershow archive

## Phase 4: Franchise Layer

- NFT collectibles
- Sponsor reporting
- Yearly Homeland Retreat qualification
- Multi-genre tournaments
- Regional expansion
- Spanish/English DR live event modules
