# Data Capture and The Listen Effect

## The Listen Effect

The Listen Effect measures how voter behavior changes after users hear preview clips before casting a vote.

It answers:

> What did people think they wanted before listening, and what did they actually choose after hearing both beats?

## Data Points

- Preview play count
- Preview completion rate
- Replay rate
- Skip rate
- Time-to-vote
- Vote after both previews
- Vote without listening
- Vote flip rate
- Underdog lift
- Name bias gap
- Blind Mode difference
- Legend alignment rate
- Committee trust score

## Segment Ideas

### The Listen Effect
Explains how previews changed voting behavior.

### Name Power vs Beat Power
Compares visible-name voting to blind voting.

### The Underdog Lift
Highlights lower seeds that gained after preview listening.

### Committee on Trial
Evaluates if committees seeded correctly.

### Legend vs The Culture
Compares expert picks against fan results.

### Instant Voters vs Careful Voters
Compares fast emotional voting to informed preview-based voting.

## Example Insight

Before previews, 71% of prediction brackets had the #2 seed winning. After both previews were played, the #11 seed captured 54% of live votes. That is The Listen Effect.
