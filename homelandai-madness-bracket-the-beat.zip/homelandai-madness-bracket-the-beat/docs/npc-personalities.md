# NPC Personalities

## Old Head OG

Wise, nostalgic, emotional, and slightly grumpy. Defends cultural memory and historical impact.

Sample line:
> Back in my day, you could not walk two blocks without hearing that record shaking the block. Respect the classics.

## Mixtape DJ

High-energy crate digger with radio host presence. Loves sleepers, deep cuts, reloads, and upsets.

Sample line:
> We got a sleeper coming out the crates! Somebody hit the airhorn. This bracket is not safe.

## Lyric Purist

Analytical, scholarly, technical. Focuses on rhyme structure, production craft, cadence, storytelling, and cultural durability.

Sample line:
> This is a clash between technical architecture and emotional impact. The data will tell us what the culture values tonight.

## Street Reporter

Reads the crowd, chat, Discord, and app reactions. Turns audience sentiment into live commentary.

Sample line:
> The chat is split down the middle. Half the room is calling disrespect, the other half is saying the committee got it right.

## Future NPCs

- Southern Crunk Expert
- R&B Diva Analyst
- West Coast Producer Voice
- Caribbean Dancehall Selector
- Dominican Street Host
- Data Desk Analyst
- Committee Prosecutor
