# Game Design Document
## HomelandAI Madness: Bracket the Beat

## 1. Concept

HomelandAI Madness: Bracket the Beat is a bracket-style music voting game where iconic songs, beats, producers, eras, or regions compete head-to-head. Fans vote privately by phone, submit prediction brackets, debate outcomes, and compete for prizes. Committees select and seed entries. Legends can cast votes live. NPC personalities react to reveals, debates, upsets, and data.

## 2. Core Loop

1. Committees select songs/beats for a theme.
2. Selection Sunday reveals seeds and regions.
3. Fans submit prediction brackets before voting begins.
4. Matchups open round by round.
5. Fans listen to previews and vote privately.
6. Winners advance.
7. Data is analyzed and turned into aftershow content.
8. Final champion is crowned.

## 3. Player Types

### Fan Voter
Votes on matchups and participates in debate.

### Prediction Player
Fills out a bracket and competes for leaderboard prizes.

### Committee Member
Pays mandatory buy-in, selects/seeds region, competes based on seed performance.

### Legend Guest
Producer, artist, DJ, or tastemaker who locks a pick and discusses cultural voting.

### Premium Member
Receives aftershows, data dashboards, Blind Mode breakdowns, Legend Mode analysis, and extended debate content.

## 4. Game Modes

### Standard Bracket Mode
Names, seeds, and matchup data are visible. Fans vote after previews.

### Blind Preview Mode
Artist names, titles, covers, and seeds are hidden. Fans vote based only on sound.

### Legend Compare Mode
A guest producer or artist locks a vote. The system reveals Legend vote beside fan vote, prediction favorite, committee expectation, and blind result.

### Committee Accountability Mode
Committee seeds are evaluated using performance, upset bonuses, fan grade, and Listen Effect analytics.

### In-Person Event Mode
Fans attend a live venue, hear matchups through the house system, and vote privately via phone QR code.

### Remote Play Mode
Users interact with mini-players, vote from home, and follow brackets on web/app.

## 5. Prediction Scoring

- Round of 32 correct pick: 1 point
- Sweet 16 correct pick: 2 points
- Elite 8 correct pick: 4 points
- Final 4 correct pick: 8 points
- Championship correct pick: 16 points
- Tie-breaker: predicted total championship-round votes

## 6. Committee Scoring

### Base Points
- Round win: 10 points
- Sweet 16 win: 15 points
- Elite 8 win: 20 points
- Final 4 win: 25 points
- Championship win: 50 points

### Upset Bonuses
- 5-8 seed defeats 1-4 seed: +10
- 9-12 seed defeats 1-8 seed: +20
- 13-16 seed defeats any seed: +30

### Accuracy Bonuses
- #1 or #2 seed reaches Final Four: +15
- #3 seed or lower reaches Final Four: +25

### Fan Grade Multiplier
- 4.5-5.0 stars: x1.2
- 3.5-4.4 stars: x1.1
- Below 3.5: no multiplier

## 7. Mini-Player Preview System

Each matchup card includes a 10-30 second preview player for both entries. Users are encouraged or required to hear both previews before voting.

### Data Captured
- Preview play rate
- Completion rate
- Replay rate
- Skip rate
- Vote after listen
- Instant vote
- Vote flip rate
- Underdog lift
- Name bias gap
- Listen Effect score

## 8. Rewards and Badges

- Fair Voter
- Crate Listener
- Heard Both Sides
- No Skip Selector
- Deep Crate Certified
- Culture Scout
- Upset Caller
- Bracket Buster
- Legend Aligned
- Rebel Pick Winner
- Perfect Bracket

## 9. NFT Collectibles

- Inaugural Shield NFT
- Champion's Crown NFT
- Bracket Poster NFT
- Vinyl Medallion NFT
- Upset Alert NFT
- Committee Badge NFT
- Legend's Pick NFT
- Rebel Pick NFT
- Perfect Bracket NFT

## 10. Live Event Flow

1. Doors open / QR sign-in
2. Host introduces tournament rules
3. Bracket shown on big screen
4. Matchup preview playback
5. NPC commentary
6. Private phone voting
7. Result reveal
8. Debate segment
9. Upset alert if lower seed wins
10. Leaderboard update
11. Final crown ceremony

## 11. Why It Works

The format monetizes behavior fans already do organically: argue, rank, predict, defend, and debate music. HomelandAI adds structure, stakes, visuals, private voting, data capture, and premium analysis.
