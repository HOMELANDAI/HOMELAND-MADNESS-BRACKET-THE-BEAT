# Committee Rules and Scoring Guide

## Committee Buy-In

Mandatory buy-in: **$49.99 per committee member**.

## Committee Role

Committees are responsible for:

- Selecting songs/beats for a region
- Assigning seeds
- Defending seed logic during Selection Sunday
- Creating balance between obvious favorites and dangerous sleepers
- Participating in post-round accountability segments

## Regions

- East Coast
- West Coast
- South
- Midwest / International

## Scoring

### Base Points

- Round win: 10 points
- Sweet 16 win: 15 points
- Elite 8 win: 20 points
- Final 4 win: 25 points
- Championship win: 50 points

### Upset Bonuses

- 5-8 seed defeats 1-4 seed: +10
- 9-12 seed defeats 1-8 seed: +20
- 13-16 seed defeats any seed: +30

### Accuracy Bonuses

- #1 or #2 seed reaches Final Four: +15
- #3 seed or lower reaches Final Four: +25

### Fan Grade Multiplier

- 4.5-5.0 stars: x1.2
- 3.5-4.4 stars: x1.1
- Below 3.5: no multiplier

## Data-Based Accountability

Committees can also be judged by:

- Seed Respect Score
- Underdog Discovery Bonus
- Overseed Penalty
- Listen Effect validation
- Fan controversy rating
- Blind Mode result comparison
