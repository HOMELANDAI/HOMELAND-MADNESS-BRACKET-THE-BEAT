# Prize Structure

## Monthly Contest Model

- 12 monthly contests
- Tiered fan buy-ins: $19.99 / $29.99 / $49.99
- Mandatory committee buy-in: $49.99
- Monthly cash winners
- Consolation giveaways
- Timed free access to media
- Sponsored February and December contests with expanded winner pools
- Yearly Homeland Retreats
- Early-bird Legacy Member price: $99.99
- Possible creative bonuses for Legacy members

## Grand Prize Eligibility

- Level 1: Must enter 10 of 12 contests
- Level 2: Must enter 7 of 12 contests
- Level 3: Must enter 4 of 12 contests

Tie-breakers may be broken by loyalty rewards or leaderboard status.

## Fan Prize Model

Best prediction bracket receives the strongest payout. Secondary awards may include:

- Upset Caller prize
- Perfect Round prize
- Voter Streak prize
- Legend Alignment prize
- Rebel Pick prize
- Blind Mode champion prize

## Committee Prize Model

Example committee pool:

4 committees x 5 members x $49.99 = roughly $1,000 gross pool.

Suggested split:

- 1st place committee: 50%
- 2nd place committee: 25%
- 3rd place committee: 15%
- 4th place committee: 10%
