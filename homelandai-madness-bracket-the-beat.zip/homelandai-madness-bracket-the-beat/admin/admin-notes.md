# Admin Dashboard Notes

## Admin Capabilities

- Create tournament
- Add regions
- Add entries
- Assign seeds
- Create matchups
- Open and close voting
- Enter Legend's Vote
- Trigger Upset Alert
- Publish results
- Score prediction brackets
- Score committees
- Export data
- Manage NFT collectible records
- Publish social recap cards

## Debug Checklist

- Confirm every matchup has two entries
- Confirm no duplicate seed numbers in a region
- Confirm voting windows use correct timezone
- Confirm results hidden until matchup closes
- Confirm duplicate vote prevention
- Confirm winner advances to next bracket slot
- Confirm prediction brackets lock before first vote
- Confirm Legend's Vote is locked before fan result reveal
