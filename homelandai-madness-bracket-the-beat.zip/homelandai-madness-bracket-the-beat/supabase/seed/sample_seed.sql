insert into public.tournaments (title, theme, status, bracket_size)
values ('HomelandAI Madness: Bracket the Beat', '90s East Coast Edition', 'draft', 32);

insert into public.badges (name, description, category) values
('Fair Voter', 'Listened to both previews before voting.', 'listen'),
('Crate Listener', 'Listened to every preview in a round.', 'listen'),
('Heard Both Sides', 'Completed multiple informed votes.', 'listen'),
('No Skip Selector', 'Voted through a bracket without skipping previews.', 'listen'),
('Upset Caller', 'Correctly predicted an upset.', 'prediction'),
('Legend Aligned', 'Matched the Legend vote.', 'legend'),
('Rebel Pick Winner', 'Went against the Legend and won.', 'legend');

insert into public.nft_collectibles (name, rarity, unlock_condition) values
('Inaugural Shield NFT', 'Legendary', 'Granted for inaugural season participation.'),
('Champion Crown NFT', 'Legendary', 'Granted to tournament champion entry archive.'),
('Upset Alert NFT', 'Rare', 'Granted for correctly calling a major upset.'),
('Committee Badge NFT', 'Rare', 'Granted to official committee members.'),
('Vinyl Medallion NFT', 'Super Rare', 'Granted for top bracket performance.');
