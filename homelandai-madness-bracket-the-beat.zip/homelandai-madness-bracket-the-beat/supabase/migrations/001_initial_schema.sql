-- HomelandAI Madness: Bracket the Beat
-- Initial Supabase Schema

create extension if not exists "uuid-ossp";

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique,
  display_name text,
  avatar_url text,
  region text,
  loyalty_level integer default 0,
  created_at timestamptz default now()
);

create table if not exists public.tournaments (
  id uuid primary key default uuid_generate_v4(),
  title text not null,
  theme text not null,
  status text not null default 'draft',
  bracket_size integer not null default 32,
  starts_at timestamptz,
  ends_at timestamptz,
  created_at timestamptz default now()
);

create table if not exists public.regions (
  id uuid primary key default uuid_generate_v4(),
  tournament_id uuid references public.tournaments(id) on delete cascade,
  name text not null,
  color text,
  created_at timestamptz default now()
);

create table if not exists public.entries (
  id uuid primary key default uuid_generate_v4(),
  tournament_id uuid references public.tournaments(id) on delete cascade,
  region_id uuid references public.regions(id) on delete set null,
  seed integer not null,
  title text not null,
  artist text,
  producer text,
  release_year integer,
  preview_url text,
  platform_url text,
  committee_note text,
  created_at timestamptz default now()
);

create table if not exists public.matchups (
  id uuid primary key default uuid_generate_v4(),
  tournament_id uuid references public.tournaments(id) on delete cascade,
  region_id uuid references public.regions(id) on delete set null,
  round_name text not null,
  matchup_order integer not null,
  left_entry_id uuid references public.entries(id),
  right_entry_id uuid references public.entries(id),
  winner_entry_id uuid references public.entries(id),
  status text default 'upcoming',
  opens_at timestamptz,
  closes_at timestamptz,
  created_at timestamptz default now()
);

create table if not exists public.votes (
  id uuid primary key default uuid_generate_v4(),
  matchup_id uuid references public.matchups(id) on delete cascade,
  user_id uuid references public.profiles(id) on delete cascade,
  entry_id uuid references public.entries(id) on delete cascade,
  listened_left boolean default false,
  listened_right boolean default false,
  blind_mode boolean default false,
  legend_alignment boolean,
  created_at timestamptz default now(),
  unique(matchup_id, user_id)
);

create table if not exists public.preview_events (
  id uuid primary key default uuid_generate_v4(),
  matchup_id uuid references public.matchups(id) on delete cascade,
  user_id uuid references public.profiles(id) on delete cascade,
  entry_id uuid references public.entries(id) on delete cascade,
  event_type text not null,
  seconds_played numeric default 0,
  completed boolean default false,
  created_at timestamptz default now()
);

create table if not exists public.prediction_brackets (
  id uuid primary key default uuid_generate_v4(),
  tournament_id uuid references public.tournaments(id) on delete cascade,
  user_id uuid references public.profiles(id) on delete cascade,
  picks jsonb not null default '{}'::jsonb,
  tiebreaker_total_votes integer,
  locked_at timestamptz,
  score integer default 0,
  created_at timestamptz default now(),
  unique(tournament_id, user_id)
);

create table if not exists public.committees (
  id uuid primary key default uuid_generate_v4(),
  tournament_id uuid references public.tournaments(id) on delete cascade,
  region_id uuid references public.regions(id) on delete set null,
  name text not null,
  buy_in_amount numeric default 49.99,
  created_at timestamptz default now()
);

create table if not exists public.committee_members (
  id uuid primary key default uuid_generate_v4(),
  committee_id uuid references public.committees(id) on delete cascade,
  user_id uuid references public.profiles(id) on delete cascade,
  role text default 'selector',
  created_at timestamptz default now()
);

create table if not exists public.committee_scores (
  id uuid primary key default uuid_generate_v4(),
  committee_id uuid references public.committees(id) on delete cascade,
  base_points integer default 0,
  upset_bonus integer default 0,
  accuracy_bonus integer default 0,
  fan_grade numeric default 0,
  fan_multiplier numeric default 1.0,
  final_score numeric default 0,
  updated_at timestamptz default now()
);

create table if not exists public.legends (
  id uuid primary key default uuid_generate_v4(),
  name text not null,
  role text,
  bio text,
  avatar_url text,
  created_at timestamptz default now()
);

create table if not exists public.legend_votes (
  id uuid primary key default uuid_generate_v4(),
  legend_id uuid references public.legends(id) on delete cascade,
  matchup_id uuid references public.matchups(id) on delete cascade,
  entry_id uuid references public.entries(id) on delete cascade,
  reasoning text,
  locked_at timestamptz default now(),
  unique(legend_id, matchup_id)
);

create table if not exists public.badges (
  id uuid primary key default uuid_generate_v4(),
  name text not null,
  description text,
  category text,
  icon_url text,
  created_at timestamptz default now()
);

create table if not exists public.user_badges (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references public.profiles(id) on delete cascade,
  badge_id uuid references public.badges(id) on delete cascade,
  awarded_at timestamptz default now(),
  unique(user_id, badge_id)
);

create table if not exists public.nft_collectibles (
  id uuid primary key default uuid_generate_v4(),
  name text not null,
  rarity text,
  unlock_condition text,
  image_url text,
  created_at timestamptz default now()
);

create table if not exists public.events (
  id uuid primary key default uuid_generate_v4(),
  tournament_id uuid references public.tournaments(id) on delete set null,
  title text not null,
  venue text,
  city text,
  event_type text default 'hybrid',
  starts_at timestamptz,
  stream_url text,
  maestro_url text,
  twitch_url text,
  created_at timestamptz default now()
);

alter table public.profiles enable row level security;
alter table public.votes enable row level security;
alter table public.prediction_brackets enable row level security;
alter table public.preview_events enable row level security;

create policy "Users can read profiles" on public.profiles for select using (true);
create policy "Users can update own profile" on public.profiles for update using (auth.uid() = id);
create policy "Users can insert own vote" on public.votes for insert with check (auth.uid() = user_id);
create policy "Users can read votes" on public.votes for select using (true);
create policy "Users can manage own prediction" on public.prediction_brackets for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "Users can insert own preview events" on public.preview_events for insert with check (auth.uid() = user_id);
create policy "Users can read preview events" on public.preview_events for select using (true);
