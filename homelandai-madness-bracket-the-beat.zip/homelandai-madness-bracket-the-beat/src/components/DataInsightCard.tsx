import React from 'react';

export function DataInsightCard({ title, value, description }: { title: string; value: string; description: string }) {
  return (
    <article className="data-card">
      <h3>{title}</h3>
      <strong>{value}</strong>
      <p>{description}</p>
    </article>
  );
}
