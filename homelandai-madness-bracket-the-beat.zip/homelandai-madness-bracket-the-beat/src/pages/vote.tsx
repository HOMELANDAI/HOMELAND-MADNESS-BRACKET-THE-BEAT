import React from 'react';
import { MatchupCard } from '../components/MatchupCard';

export default function VotePage() {
  return (
    <main className="page">
      <h1>Vote Live</h1>
      <p>One phone. One vote. No pressure.</p>
      <MatchupCard
        status="live"
        left={{ seed: 3, title: 'Beat A Placeholder', artist: 'Artist A' }}
        right={{ seed: 14, title: 'Beat B Placeholder', artist: 'Artist B' }}
      />
    </main>
  );
}
