import React from 'react';
import { DataInsightCard } from '../components/DataInsightCard';

export default function DataLabPage() {
  return (
    <main className="page">
      <h1>HAI Data Lab</h1>
      <DataInsightCard title="Most Replayed Preview" value="Pending" description="The preview that fans replayed most before voting." />
      <DataInsightCard title="Biggest Vote Flip" value="Pending" description="The matchup where preview listening changed the likely winner." />
      <DataInsightCard title="Legend Alignment Rate" value="Pending" description="How often fans agreed with the featured legend." />
    </main>
  );
}
