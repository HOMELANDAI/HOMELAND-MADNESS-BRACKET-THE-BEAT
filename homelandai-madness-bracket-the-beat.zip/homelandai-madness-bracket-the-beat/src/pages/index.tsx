import React from 'react';
import { sampleTournament } from '../data/sampleTournament';
import { DataInsightCard } from '../components/DataInsightCard';

export default function HomePage() {
  return (
    <main className="page">
      <section className="hero">
        <p className="eyebrow">By HAI / HomelandAI</p>
        <h1>{sampleTournament.title}</h1>
        <h2>{sampleTournament.theme}</h2>
        <p>{sampleTournament.tagline}</p>
        <div className="cta-row">
          <a href="/bracket">View Bracket</a>
          <a href="/vote">Vote Live</a>
          <a href="/selection-sunday">Watch Selection Sunday</a>
        </div>
      </section>
      <section className="insights">
        <DataInsightCard title="The Listen Effect" value="Preview-driven voting" description="Track how fan choices change after hearing both previews." />
        <DataInsightCard title="Blind Mode" value="No names. Just sound." description="Measure beat power without artist-name bias." />
        <DataInsightCard title="Legend Mode" value="Expert vs Culture" description="Compare producer or artist picks against fan consensus." />
      </section>
    </main>
  );
}
