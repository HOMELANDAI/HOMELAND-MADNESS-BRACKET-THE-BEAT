export const sampleTournament = {
  title: 'HomelandAI Madness: Bracket the Beat',
  theme: '90s East Coast Edition',
  tagline: 'Vote. Debate. Crown the Era.',
  regions: ['East Coast', 'West Coast', 'South', 'Midwest / International'],
  features: [
    'Private phone voting',
    'Mini-player previews',
    'Listen-to-Vote XP',
    'Blind Preview Mode',
    "Legend's Vote",
    'Committee scoring',
    'The Listen Effect'
  ]
};
